$.extend(true, $.fn.dataTable.defaults, {
    dom: '<"row buttons-container"<"col-sm-12"B>>' + $.fn.dataTable.defaults.dom,
    buttons: []
});
