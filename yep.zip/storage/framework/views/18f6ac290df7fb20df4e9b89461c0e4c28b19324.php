<?php $__env->startSection('content'); ?>
  <h1>Cadastro de <?php echo e($base['singular']); ?></h1>
  <hr/>
  <?php echo $__env->make('errors._check', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


  <?php echo Form::open ( [ 'route' => $base['base'].'.store','class'=>'form-horizontal' ] ); ?>

    <?php echo $__env->make($base['base'].'._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="form-group">
      <?php echo Form::submit('Salvar', [ 'class' => 'btn btn-primary pull-right' ]); ?>

    </div>
  <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>