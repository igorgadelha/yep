<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col">
    <table class="table stable striped">
        <thead>
            <tr>
                <th>Product</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Subtotal</th>
                <th>Action</th>
            </tr>
        </thead>

        <tbody>

            <?php foreach(Cart::content() as $row) :?>
                <tr>
                    <td>
                        <p><strong><?php echo $row->name; ?></strong></p>
                        <p><?php echo ($row->options->has('size') ? $row->options->size : ''); ?></p>
                    </td>
                    <td><input type="number" value="<?php echo $row->qty; ?>"  id="qty-<?php echo e($row->rowId); ?>"></td>
                    <td>$<?php echo $row->price; ?></td>
                    <td>$<?php echo $row->total; ?></td>
                    <td>
                      <?php echo e(Form::open(array('route' => array('cart.update', $row->rowId), 'method' => 'put', 'style'=> 'display: inline'))); ?>

                          <input type="hidden" name="qty" id="qty-<?php echo e($row->rowId); ?>-2">
                          <button type="submit" class="btn  btn-warning" onclick="$('#qty-<?php echo e($row->rowId); ?>-2').val( $('#qty-<?php echo e($row->rowId); ?>').val() )">Atualizar</button>
                      <?php echo e(Form::close()); ?>

                      <?php echo e(Form::open(array('route' => array('cart.destroy', $row->rowId), 'method' => 'delete', 'style'=> 'display: inline'))); ?>

                          <button type="submit" class="btn  btn-danger">Remover</button>
                      <?php echo e(Form::close()); ?>

                    </td>
                </tr>

            <?php endforeach;?>

        </tbody>

        <tfoot>
            <tr>
                <td colspan="2">&nbsp;</td>
                <td>Subtotal</td>
                <td><?php echo Cart::subtotal(); ?></td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
                <td>Tax</td>
                <td><?php echo Cart::tax(); ?></td>
            </tr>
            <tr>
                <td colspan="2">&nbsp;</td>
                <td>Total</td>
                <td><?php echo Cart::total(); ?></td>
            </tr>
        </tfoot>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>