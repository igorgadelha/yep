<?php $__env->startSection('content'); ?>
  <h1><?php echo e($base['plural']); ?></h1>
  <hr/>
  <div class="row">
    <div class="col-md-12">
      <ul class="nav">
        <form class="form-inline">
          <input class="form-control mr-sm-2" type="text" placeholder="Pesquisar">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
        </form>
        <li class="nav-item ml-auto">
          <a class="nav-link btn-outline-info" href="<?php echo e(route( $base['base'].'.create' )); ?>">Cadastrar</a>
        </li>
      </ul>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col">
      <table class="table table-striped">
        <thead>
          <tr>
            <td>id</td>
            <td>Código</td>
            <td>Valor</td>
            <td>Ações</td>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td>#<?php echo e($cat->id); ?></td>
              <td><?php echo e($cat->code); ?></td>
              <td><?php echo e($cat->value); ?></td>
              <td>
                  <a href="<?php echo e(route( $base['base'].'.edit',['id' => $cat->id ])); ?>" class="btn btn-sm btn-info"><i class="fa-pencil" aria-hidden="true"></i></a>
                  <?php echo e(Form::open(array('route' => array($base['base'].'.destroy', $cat->id), 'method' => 'delete', 'style'=> 'display: inline'))); ?>

                      <button type="submit" class="btn btn-sm btn-danger"><i class="fa-trash-o" aria-hidden="true"></i></button>
                  <?php echo e(Form::close()); ?>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

    </div>
  </div>

  <?php echo $data->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>