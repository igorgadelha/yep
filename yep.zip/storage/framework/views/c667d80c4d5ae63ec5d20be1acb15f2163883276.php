<?php echo Form::label('name','Nome:', ['class' => 'sr-only', 'for'=>'name']); ?>

<?php echo Form::text('name',null, [ 'class' => 'form-control mb-2 mr-sm-2 mb-sm-0', 'id'=>'name', 'placeholder'=> 'Nome']); ?>

