<?php $__env->startSection('content'); ?>
  <h1><?php echo e($base['plural']); ?></h1>
  <hr/>
  <div class="row">
    <div class="col-md-12">
      <ul class="nav">
        <form class="form-inline">
          <input class="form-control mr-sm-2" type="text" placeholder="Pesquisar">
          <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Pesquisar</button>
        </form>
      </ul>
    </div>
  </div>
  <br>
  <div class="row">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class=" col-md-4">
                <div class="card mb-3">
                  <div class="card-block">
                    <h4 class="card-title"><?php echo e($cat->name); ?></h4>
                    <h6 class="card-subtitle mb-2 text-muted"><?php echo e($cat->price); ?></h6>
                    <p class="card-text"><?php echo e($cat->description); ?></p>
                    <a href="<?php echo e(route('cart.add',['id' => $cat->id ])); ?>" class="card-link">Adicionar ao carrinho</a>
                  </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <?php echo $data->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>