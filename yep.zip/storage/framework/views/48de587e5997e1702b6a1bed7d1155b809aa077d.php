<?php $__env->startSection('content'); ?>
  <h1>Nova Categoria</h1>
  <hr/>
  <?php echo $__env->make('errors._check', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="row">
    <div class="col">
      <?php echo Form::open ( [ 'route' => 'categories.store','class'=>'form-inline' ] ); ?>

      <?php echo $__env->make('categories._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo Form::submit('Salvar', [ 'class' => 'btn btn-primary' ]); ?>

      <?php echo Form::close(); ?>

    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>