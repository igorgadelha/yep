<nav class="breadcrumb">
  <a class="breadcrumb-item" href="/">Home</a>
  <?php for($i = 0; $i <= count(Request::segments()); $i++): ?>
    <a class="breadcrumb-item" href="<?php echo e(Request::url($i)); ?>"><?php echo e(Request::segment($i)); ?></a>
  <?php endfor; ?>
</nav>
