<?php $__env->startSection('content'); ?>
<div class="container">
  <h1>Editanto categoria <?php echo e($data->name); ?></h1>
  <hr/>
  <?php echo $__env->make('errors._check', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <div class="row">
    <div class="col">
      <?php echo Form::model ( $data,[ 'route' => [ 'categories.update', $data->id ], 'class' => 'form-inline' ] ); ?>

        <?php echo $__env->make('categories._form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <?php echo Form::submit('Salvar', [ 'class' => 'btn btn-primary' ]); ?>

      <?php echo Form::close(); ?>

  </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>