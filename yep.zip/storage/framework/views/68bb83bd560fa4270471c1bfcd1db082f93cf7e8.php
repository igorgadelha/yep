<div class="form-group">
  <?php echo Form::label('status','Status:', ['class' => 'control-label']); ?>

  <?php echo Form::select('status', $status, null, [ 'class' => 'form-control' ]); ?>

</div>

<div class="form-group">
  <?php echo Form::label('deliveryman','Entregador:', ['class' => 'control-label']); ?>

  <?php echo Form::select('user_deliveryman_id', $deliverymen, null, [ 'class' => 'form-control' ]); ?>

</div>
