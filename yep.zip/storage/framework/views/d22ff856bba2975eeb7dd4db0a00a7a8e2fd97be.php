<div class="form-group">
  <?php echo Form::label('name','Nome:', ['class' => 'control-label']); ?>

  <?php echo Form::text('name',null, [ 'class' => 'form-control' ]); ?>

</div>

<div class="form-group">
  <?php echo Form::label('Price','Preço:', ['class' => 'control-label']); ?>

  <?php echo Form::text('price',null, [ 'class' => 'form-control' ]); ?>

</div>

<div class="form-group">
  <?php echo Form::label('Category','Categoria:', ['class' => 'control-label']); ?>

  <?php echo Form::select('category_id', $categories, null, [ 'class' => 'form-control' ]); ?>

</div>

<div class="form-group">
  <?php echo Form::label('Description','Descrição:', ['class' => 'control-label']); ?>

  <?php echo Form::textarea('description',null, [ 'class' => 'form-control' ]); ?>

</div>
