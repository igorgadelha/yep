<div class="form-group">
  <?php echo Form::label('name','Nome:', ['class' => 'control-label']); ?>

  <?php echo Form::text('user[name]',null, [ 'class' => 'form-control' ]); ?>

</div>

<div class="form-group">
  <?php echo Form::label('email','Email:', ['class' => 'control-label']); ?>

  <?php echo Form::email('user[email]',null, [ 'class' => 'form-control' ]); ?>

</div>

<div class="form-group">
  <?php echo Form::label('Phone','Telefone:', ['class' => 'control-label']); ?>

  <?php echo Form::text('phone',null, [ 'class' => 'form-control' ]); ?>

</div>

<div class="form-group">
  <?php echo Form::label('Address','Endereço:', ['class' => 'control-label']); ?>

  <?php echo Form::textarea('address',null, [ 'class' => 'form-control' ]); ?>

</div>

<div class="form-group">
  <?php echo Form::label('city','Cidade:', ['class' => 'control-label']); ?>

  <?php echo Form::text('city',null, [ 'class' => 'form-control' ]); ?>

</div>

<div class="form-group">
  <?php echo Form::label('State','Estado:', ['class' => 'control-label']); ?>

  <?php echo Form::text('state',null, [ 'class' => 'form-control' ]); ?>

</div>

<div class="form-group">
  <?php echo Form::label('Zipcode','CEP:', ['class' => 'control-label']); ?>

  <?php echo Form::text('zipcode',null, [ 'class' => 'form-control' ]); ?>

</div>
